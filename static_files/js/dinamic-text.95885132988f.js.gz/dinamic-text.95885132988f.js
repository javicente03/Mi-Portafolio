var text1 = "Systems engineer, with one year of experience in web development, \
        I have knowledge of technologies, Python\
        Php, Java, JavaScript, HTML, CSS, MySQL and PostgreSQL, specializing in the \
        development and consumption of APIs Rest and Web Scraping.";
var text2 = "If you want a software as you can contact me.";
var text3 = "I am constantly learning and professional and personal growth.";
var textEnglish = [text1, text2, text3];

var text4 = "Ingeniero de sistemas, con un año de experiencia en el desarrollo web, \
        tengo conocimientos de las tecnologías Python, \
        Php, Java, JavaScript, HTML, CSS, MySQL y PostgreSQL, especializado en el \
        desarrollo y consumo de APIs Rest y Web Scraping.";
var text5 = "Si deseas un software a medida puedes contactarme.";
var text6 = "Estoy en constante aprendizaje y crecimiento profesional y personal.";
var textSpanish = [text4, text5, text6];

var language = 'es';