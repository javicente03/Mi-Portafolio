// Inicialización de los elementos de Materialize	
// Inicialización del material boxed
$(document).ready(function(){
    $('.materialboxed').materialbox();
});

// Inicialización del parallax
$(document).ready(function(){
    $('.parallax').parallax();
});

//Inicialización del Scrollspy
$(document).ready(function(){
    $('.scrollspy').scrollSpy();
});

// Inicialización del Modal
// $(document).ready(function(){
//     $('.modal').modal();
// })

// Inicialización del collapsible
$(document).ready(function(){
    $('.collapsible').collapsible();
});

// Inicialización del tooltip
$(document).ready(function(){
    $('.tooltipped').tooltip();
});

// Inicialización del Sidenav
$(document).ready(function(){
    $('.sidenav').sidenav();
});